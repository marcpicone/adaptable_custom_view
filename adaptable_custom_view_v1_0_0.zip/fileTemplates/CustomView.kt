## MANDATORY PARAMETERS --------------------------------
#set($hasViewManager = $VIEW_MANAGER_default_false)
## -----------------------------------------------------
## You could have a preset value for compose here, 
## just uncoment the good set directive and apply change.
## -----------------------------------------------------
## #set($IS_COMPOSE_default_true = "true") 
## #set($IS_COMPOSE_default_true = "false") 
## -----------------------------------------------------
#set($isCompose = $IS_COMPOSE_default_true)
## -----------------------------------------------------
#if($isCompose == "false")
#parse("ScreenMvpCode.kt")
#else
#parse("ScreenComposeCode.kt")
#end