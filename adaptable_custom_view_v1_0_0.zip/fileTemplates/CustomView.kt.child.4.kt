#if($IS_COMPOSE_default_true == "false")
#parse("ContractMvpCode.kt")
#else
#parse("ContractComposeCode.kt")
#end