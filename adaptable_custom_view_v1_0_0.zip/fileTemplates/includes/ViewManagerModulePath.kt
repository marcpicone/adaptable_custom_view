## ------------------------ NAME_TRANSFORMATION ------------------------------
## Used because when use parse directive in if directive lead to unexpected behaviour
## ---------------------------------------------------------------------------
#set($folder = "")
#set($foreach = "")
#set($rootRelativePath = "")
#set($endRootPath = "..")
#foreach ($folder in ${StringUtils.split(${PACKAGE_NAME},".")})
#set($rootRelativePath = "$!rootRelativePath../")
#if ($foreach.hasNext == false)
#set($rootRelativePath = "$!rootRelativePath$endRootPath")
#end
#end
#set($path = "")
## --------------------------------------------------------------------------------
#if($VIEW_MANAGER_default_false == "true")
#set($path = "${NAME}" )
#else
#set($path = "${rootRelativePath}/../../build/file_template_trash/${NAME}_${TIME}" )
#end
$path/#parse("NameToCamelCase.kt")Module