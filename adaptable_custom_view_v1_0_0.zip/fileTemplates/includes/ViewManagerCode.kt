## -------------------------- MODEL_NAME ---------------------------
#if($IS_COMPOSE_default_true == "false")
#set($modelName = "ViewModel")
#else
#set($modelName = "DataModel")
#end
## -------------------------- MODEL_NAME_POST_FIX ---------------------------
#set($modelNamePostFix = "")
#if($IS_COMPOSE_default_true == "false")
#set($modelNamePostFix = "Model")
#else
#set($modelNamePostFix = "DataModel")
#end
## -------------------------- MODEL_NAME_TO_LOWER_CAMEL_CASE ---------------------------
#set($firstLetter = $modelName.substring(0,1).toLowerCase())
#set($theRest = $modelName.substring(1))
#set($modelNameToLowerCamelCase = ${firstLetter} + ${theRest})
## --------------------------------------------------------------------------------
#if (${PACKAGE_NAME} && ${PACKAGE_NAME} != "")package ${PACKAGE_NAME}.${NAME}
#end
interface #parse("NameToCamelCase.kt")Manager{

    fun get${modelName}(): #parse("NameToCamelCase.kt")${modelNamePostFix}?

    fun set${modelName}(${modelNameToLowerCamelCase}: #parse("NameToCamelCase.kt")${modelNamePostFix}?)
    
    fun addListener(listener: Listener)

    fun removeListener(listener: Listener)

    interface Listener {

        fun onChange()
    }
}