## ------------------------ NAME_TRANSFORMATION ------------------------------
## Used because when use parse directive in if directive lead to unexpected behaviour
## ---------------------------------------------------------------------------
#set($nameToCamelCase = ${StringUtils.removeAndHump(${NAME}, "_")})
#set($firstLetter = $nameToCamelCase.substring(0,1).toLowerCase())
#set($theRest = $nameToCamelCase.substring(1))
#set($nameToLowerCamelCase = ${firstLetter} + ${theRest})
## -------------------------- PRESENTER_DECLARATION ---------------------------
#if($VIEW_MANAGER_default_false == "true")
#set($presenterDeclaration = "
    private val ${nameToLowerCamelCase}Manager : ${nameToCamelCase}Manager,
")
#else
#set($presenterDeclaration = "")
#end
## ------------------------------------------------------------------
#if (${PACKAGE_NAME} && ${PACKAGE_NAME} != "")package ${PACKAGE_NAME}.${NAME}
#end
#parse("File Header.java")
class #parse("NameToCamelCase.kt")Presenter(${presenterDeclaration}
     private val screen : #parse("NameToCamelCase.kt")Contract.Screen
) : #parse("NameToCamelCase.kt")Contract.UserAction {

## -------------------------- LISTENER_IF_VIEW_MANAGER ---------------------------
    #if($VIEW_MANAGER_default_false == "true")
    private val ${nameToLowerCamelCase}Listener = create${nameToCamelCase}Listener()
    #end
## --------------------------------------------------------------------------------
    
    override fun onAttachedToWindow(){
## -------------------------- ADD_LISTENER_IF_VIEW_MANAGER ---------------------------
    #if($VIEW_MANAGER_default_false == "true")
        ${nameToLowerCamelCase}Manager.addListener(${nameToLowerCamelCase}Listener)
        updateScreen()
    #end
## --------------------------------------------------------------------------------
    }
    
     override fun onDetachedFromWindow(){
## -------------------------- REMOVE_LISTENER_IF_VIEW_MANAGER ---------------------------
     #if($VIEW_MANAGER_default_false == "true")
        ${nameToLowerCamelCase}Manager.removeListener(${nameToLowerCamelCase}Listener)
    #end
## --------------------------------------------------------------------------------
    }

## -------------------------- BODY_IF_VIEW_MANAGER ---------------------------
    #if($VIEW_MANAGER_default_false == "true")
    override fun onClosed(){
        updateVisibility()
    }
    
    private fun updateScreen() {
        updateVisibility()
    }
    
    private fun updateVisibility(){
        screen.setVisibility(createVisibility())
    }
    
    private fun createVisibility(): Boolean{
        return ${nameToLowerCamelCase}Manager.getViewModel() != null
    }
        
    private fun create${nameToCamelCase}Listener() = object: ${nameToCamelCase}Manager.Listener {
        override fun onChange() {
            screen.setVisibility(${nameToLowerCamelCase}Manager.getViewModel() != null)
        }
    }
    #end
## --------------------------------------------------------------------------------
}