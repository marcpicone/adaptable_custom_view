#set($modifiedName = ${StringUtils.removeAndHump(${ARG1}, "_")})
#set($firstLetter = $modifiedName.substring(0,1).toLowerCase())
#set($theRest = $modifiedName.substring(1))
#set($snakeCaseToLowerCamelCase = ${firstLetter} + ${theRest})
$snakeCaseToLowerCamelCase