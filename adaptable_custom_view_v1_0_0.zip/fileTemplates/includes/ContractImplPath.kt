#set($suffix = "")
#if($IS_COMPOSE_default_true == "false")
#set($suffix = "Presenter" )
#else
#set($suffix = "ModelImpl" )
#end
${NAME}/#parse("NameToCamelCase.kt")$suffix