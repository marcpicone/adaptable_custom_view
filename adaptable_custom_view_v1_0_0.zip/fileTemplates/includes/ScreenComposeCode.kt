## ------------------------ NAME_TRANSFORMATION ------------------------------
## Used because when use parse directive in if directive lead to unexpected behaviour
## ---------------------------------------------------------------------------
#set($nameToCamelCase = ${StringUtils.removeAndHump(${NAME}, "_")})
#set($modifiedName = ${StringUtils.removeAndHump(${NAME}, "_")})
#set($firstLetter = $modifiedName.substring(0,1).toLowerCase())
#set($theRest = $modifiedName.substring(1))
#set($nameToLowerCamelCase = ${firstLetter} + ${theRest})
## -------------------------- VIEW_MODEL_DECLARATION ---------------------------
#set($viewModelDeclaration = "")
#if($VIEW_MANAGER_default_false == "true")
#set($viewModelDeclaration = "(
    #[[$GRAPH$]]#.get${nameToCamelCase}Manager()
)")
#else
#set($viewModelDeclaration = "()")
#end
## --------------------- VIEW_MODEL_PREVIEW_DECLARATION ---------------------------
#set($viewModelPreviewDeclaration = "")
#if($VIEW_MANAGER_default_false == "true")
#set($viewModelPreviewDeclaration = "{
    override val isVisible: State<Boolean>
        get() = mutableStateOf(true)
    override fun onClosed(){}
}")
#else
#set($viewModelPreviewDeclaration = "{}")
#end
## --------------------------------------------------------------------------
#if (${PACKAGE_NAME} && ${PACKAGE_NAME} != "")package ${PACKAGE_NAME}.${NAME}
#end
import androidx.compose.runtime.Composable
## -------------------------- IMPORT_IF_VIEW_MANAGER ---------------------------
#if($VIEW_MANAGER_default_false == "true")
import androidx.compose.runtime.State
import androidx.compose.runtime.mutableStateOf
#end
## --------------------------------------------------------------------------------
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalInspectionMode
import androidx.compose.ui.tooling.preview.Preview
import androidx.lifecycle.viewmodel.compose.viewModel
import androidx.lifecycle.viewmodel.initializer
import androidx.lifecycle.viewmodel.viewModelFactory

## ------------------------ LIVE_TEMPLATE ------------------------------
## Could be used only in the parent template because this is the one that will
## be openned in your IDE on creation. Allow to automatically jump to empty val
## ---------------------------------------------------------------------------
/**
* Figma Link : #[[$FIGMA_LINK$]]#
*/ 
## --------------------------------------------------------------------------------

@Composable
fun #parse("NameToCamelCase.kt")(
    modifier: Modifier = Modifier
) {
    val viewModel = createViewModel()
## ------------------------ VISIBILITY_IF_VIEW_MANAGER ------------------------------
    #if($VIEW_MANAGER_default_false == "true")
    if (viewModel.isVisible.value){
        #[[$END$]]#
    }
    #end
## --------------------------------------------------------------------------------
}

@Preview
@Composable
private fun #parse("NameToCamelCase.kt")Preview() {
     #[[$THEME$]]#{
        #parse("NameToCamelCase.kt")()
    }
}

@Composable
private fun createViewModel(): #parse("NameToCamelCase.kt")Model {
    if (LocalInspectionMode.current) {
        return object : #parse("NameToCamelCase.kt")Model${viewModelPreviewDeclaration}
    }

    return viewModel<#parse("NameToCamelCase.kt")ModelImpl>(
        factory = viewModelFactory {
            initializer {
                #parse("NameToCamelCase.kt")ModelImpl ${viewModelDeclaration}
            }
        }
    )
}
