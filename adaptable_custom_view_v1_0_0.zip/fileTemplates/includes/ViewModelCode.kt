## -------------------------- MODEL_NAME ---------------------------
#set($modelName = "")
#if($IS_COMPOSE_default_true == "false")
#set($modelName = "Model")
#else
#set($modelName = "DataModel")
#end
## ------------------------------------------------------------------------
#if (${PACKAGE_NAME} && ${PACKAGE_NAME} != "")package ${PACKAGE_NAME}.${NAME}

#end
#parse("File Header.java")
class #parse("NameToCamelCase.kt")$modelName