#set($suffix = "")
#if($IS_COMPOSE_default_true == "false")
#set($suffix = "Contract" )
#else
#set($suffix = "Model" )
#end
${NAME}/#parse("NameToCamelCase.kt")$suffix
