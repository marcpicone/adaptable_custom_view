#if (${PACKAGE_NAME} && ${PACKAGE_NAME} != "")package ${PACKAGE_NAME}.${NAME}

#end
#parse("File Header.java")
interface #parse("NameToCamelCase.kt")Contract {

    interface UserAction {
 
## -------------------------- CLOSE_IF_VIEW_MANAGER ---------------------------
    #if($VIEW_MANAGER_default_false == "true")
        fun onClosed()
       
    #end
## --------------------------------------------------------------------------------
        fun onAttachedToWindow()

        fun onDetachedFromWindow()
    }

    interface Screen {
## --------------------- SCREEN_VISIBILTY_IF_VIEW_MANAGER ---------------------------
    #if($VIEW_MANAGER_default_false == "true")
        fun setVisibility(visible: Boolean)
    #end
## --------------------------------------------------------------------------------
    }
}