## -------------------------- MODEL_NAME ---------------------------
#set($modelName = "")
#if($IS_COMPOSE_default_true == "false")
#set($modelName = "Model")
#else
#set($modelName = "DataModel")
#end
## -------------------------- FUNCTION_MODEL_NAME ---------------------------
#set($functionModelName = "")
#if($IS_COMPOSE_default_true == "false")
#set($functionModelName = "ViewModel")
#else
#set($functionModelName = "DataModel")
#end
## -------------------------- MODEL_NAME_TO_LOWER_CAMEL_CASE ---------------------------
#set($firstLetter = $functionModelName.substring(0,1).toLowerCase())
#set($theRest = $functionModelName.substring(1))
#set($modelNameToLowerCamelCase = ${firstLetter} + ${theRest})
## --------------------------------------------------------------------------------
#if (${PACKAGE_NAME} && ${PACKAGE_NAME} != "")package ${PACKAGE_NAME}.${NAME}
#end
class #parse("NameToCamelCase.kt")ManagerImpl : #parse("NameToCamelCase.kt")Manager{
    
    private val listeners = ArrayList<#parse("NameToCamelCase.kt")Manager.Listener>()
    private var ${modelNameToLowerCamelCase}: #parse("NameToCamelCase.kt")$modelName? = null
    
    override fun get${functionModelName}(): #parse("NameToCamelCase.kt")${modelName}?{
        return ${modelNameToLowerCamelCase}
    }

    override fun set${functionModelName}(${modelNameToLowerCamelCase}: #parse("NameToCamelCase.kt")${modelName}?){
        if (this.${modelNameToLowerCamelCase} == ${modelNameToLowerCamelCase}){
            return
        }
        this.${modelNameToLowerCamelCase} = ${modelNameToLowerCamelCase}
        for (listener in listeners){
            listener.onChange()
        }
    }

    override fun addListener(listener: #parse("NameToCamelCase.kt")Manager.Listener) {
        if (listeners.contains(listener)) {
            return
        }
        listeners.add(listener)
    }

    override fun removeListener(listener: #parse("NameToCamelCase.kt")Manager.Listener) {
        listeners.remove(listener)
    }
}