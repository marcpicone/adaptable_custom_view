#if (${PACKAGE_NAME} && ${PACKAGE_NAME} != "")package ${PACKAGE_NAME}.${NAME}

#end
#parse("File Header.java")
## ----------------------------- IMPORT_FOR_VIEW_MANAGER --------------------------
#if($VIEW_MANAGER_default_false == "true")
import androidx.compose.runtime.State
#end
## -----------------------------------------------------------------------------
interface #parse("NameToCamelCase.kt")Model{

## ----------------------------- BODY_FOR_VIEW_MANAGER --------------------------
#if($VIEW_MANAGER_default_false == "true")
    val isVisible: State<Boolean>
    
    fun onClosed()
#end
## ------------------------------------------------------------------------------
}