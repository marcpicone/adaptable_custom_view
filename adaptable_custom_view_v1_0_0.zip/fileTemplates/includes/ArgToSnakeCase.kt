#set( $regex = "([a-z])([A-Z]+)")
#set( $replacement = "$1_$2")
#set( $toDash = $ARG1.replaceAll($regex, $replacement).toLowerCase())
${toDash}