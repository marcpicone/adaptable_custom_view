## ------------------------ NAME_TRANSFORMATION ------------------------------
## Used because when use parse directive in if directive lead to unexpected behaviour
## ---------------------------------------------------------------------------
#set($folder = "")
#set($foreach = "")
#set($rootRelativePath = "")
#set($endRootPath = "..")
#foreach ($folder in ${StringUtils.split(${PACKAGE_NAME},".")})
#set($rootRelativePath = "$!rootRelativePath../")
#if ($foreach.hasNext == false)
#set($rootRelativePath = "$!rootRelativePath$endRootPath")
#end
#end
#set($path = "")
## --------------------------------------------------------------------------------
#if($IS_COMPOSE_default_true == "false")
#set($path = "${rootRelativePath}/res/${NAME}/layout/${NAME}")
#else
#set($path = "${rootRelativePath}/../../build/file_template_trash/${NAME}_${TIME}/layout/${NAME}_${TIME}")
#end
$path