#if (${PACKAGE_NAME} && ${PACKAGE_NAME} != "")package ${PACKAGE_NAME}.${NAME}#end

class #parse("NameToCamelCase.kt")Module {
    
    fun create#parse("NameToCamelCase.kt")Manager () : #parse("NameToCamelCase.kt")Manager {
        return #parse("NameToCamelCase.kt")ManagerImpl()
    }
}