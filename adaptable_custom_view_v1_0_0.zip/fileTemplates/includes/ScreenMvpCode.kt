## ------------------------ NAME_TRANSFORMATION ------------------------------
## Used because when use parse directive in if directive lead to unexpected behaviour
## ---------------------------------------------------------------------------
#set($nameToCamelCase = ${StringUtils.removeAndHump(${NAME}, "_")})
## --------------------------------------------------------------------------------
#if (${PACKAGE_NAME} && ${PACKAGE_NAME} != "")package ${PACKAGE_NAME}.${NAME}
import android.content.Context
import android.util.AttributeSet
import android.view.View
import android.widget.FrameLayout
import androidx.annotation.IdRes
import ${PACKAGE_NAME}.R

#end
#parse("File Header.java")
class #parse("NameToCamelCase.kt") @JvmOverloads constructor(
    context: Context,
    attrs: AttributeSet? = null,
    defStyleAttr: Int = 0
) : FrameLayout(context, attrs, defStyleAttr) {

    private val view = inflate(context, R.layout.${NAME}, this)
    private val userAction by lazy { createUserAction() }

    override fun onAttachedToWindow() {
        super.onAttachedToWindow()
        userAction.onAttachedToWindow()
    }

    override fun onDetachedFromWindow() {
        super.onDetachedFromWindow()
        userAction.onDetachedFromWindow()
    }

    private fun <T : View> bind(@Suppress("SameParameterValue") @IdRes id: Int): T {
        @Suppress("RemoveExplicitTypeArguments")
        return view.findViewById<T>(id)
    }

    private fun createScreen() = object : #parse("NameToCamelCase.kt")Contract.Screen {
## -------------------------- VISIBILITY_IF_VIEW_MANAGER ---------------------------
    #if($VIEW_MANAGER_default_false == "true")
        override fun setVisibility(visible: Boolean){
            view.visibility = if(visible){
                VISIBLE
            }else {
                GONE
            } 
        }
    #end
## --------------------------------------------------------------------------------
    }

    private fun createUserAction(): #parse("NameToCamelCase.kt")Contract.UserAction {
        if (isInEditMode) {
            return object : #parse("NameToCamelCase.kt")Contract.UserAction {
                override fun onAttachedToWindow() {}
                override fun onDetachedFromWindow() {}
                #if($VIEW_MANAGER_default_false == "true")
                override fun onClosed() {}
                #end
            }
        }
        return #parse("NameToCamelCase.kt")Presenter(
## -------------------------- GRAPH_CALL_IF_VIEW_MANAGER ---------------------------
            #if($VIEW_MANAGER_default_false == "true")
            #[[$GRAPH$]]#.get${nameToCamelCase}Manager(),
            #end
## --------------------------------------------------------------------------------
            createScreen()
        )
    }
}
