#if($IS_COMPOSE_default_true == "false")
#parse("ContractImplMvpCode.kt")
#else
#parse("ContractImplComposeCode.kt")
#end